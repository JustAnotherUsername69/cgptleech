# Replace with your actual Telegram Bot API key
TELEGRAM_API_KEY = "YOUR_BOT_API_KEY"
